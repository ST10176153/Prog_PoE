﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace RecipeApp
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();
        private Recipe currentRecipe;

        public MainWindow()
        {
            InitializeComponent();
            UpdateRecipeListBox();
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe == null)
            {
                currentRecipe = new Recipe(RecipeNameTextBox.Text);
            }

            string ingredientName = IngredientNameTextBox.Text;
            if (double.TryParse(QuantityTextBox.Text, out double quantity) &&
                int.TryParse(CaloriesTextBox.Text, out int calories))
            {
                string unit = UnitTextBox.Text;
                string foodGroup = FoodGroupTextBox.Text;
                Ingredient ingredient = new Ingredient(ingredientName, quantity, unit, calories, foodGroup);
                currentRecipe.AddIngredient(ingredient);
                MessageBox.Show($"Ingredient {ingredientName} added.");
                ClearIngredientFields();
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter valid numbers for quantity and calories.");
            }
        }

        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe == null)
            {
                MessageBox.Show("Please enter the recipe name first.");
                return;
            }

            string stepDescription = StepDescriptionTextBox.Text;
            if (!string.IsNullOrWhiteSpace(stepDescription))
            {
                currentRecipe.AddStep(stepDescription);
                MessageBox.Show($"Step added: {stepDescription}");
                StepDescriptionTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a step description.");
            }
        }

        private void SaveRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe != null)
            {
                recipes.Add(currentRecipe);
                currentRecipe = null;
                ClearAllFields();
                MessageBox.Show("Recipe saved.");
                UpdateRecipeListBox();
            }
            else
            {
                MessageBox.Show("No recipe to save.");
            }
        }

        private void UpdateRecipeListBox()
        {
            RecipeListBox.ItemsSource = null;
            RecipeListBox.ItemsSource = recipes.OrderBy(r => r.Name).Select(r => r.Name).ToList();
        }

        private void DisplayRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListBox.SelectedItem != null)
            {
                string selectedRecipeName = RecipeListBox.SelectedItem.ToString();
                Recipe selectedRecipe = recipes.FirstOrDefault(r => r.Name.Equals(selectedRecipeName, StringComparison.OrdinalIgnoreCase));
                if (selectedRecipe != null)
                {
                    string recipeDetails = $"Recipe: {selectedRecipe.Name}\n\nIngredients:\n";
                    foreach (var ingredient in selectedRecipe.Ingredients)
                    {
                        recipeDetails += $"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} ({ingredient.Calories} calories, {ingredient.FoodGroup})\n";
                    }
                    recipeDetails += "\nSteps:\n";
                    for (int i = 0; i < selectedRecipe.Steps.Count; i++)
                    {
                        recipeDetails += $"{i + 1}. {selectedRecipe.Steps[i]}\n";
                    }
                    recipeDetails += $"\nTotal Calories: {selectedRecipe.CalculateTotalCalories()}";
                    MessageBox.Show(recipeDetails);
                }
            }
            else
            {
                MessageBox.Show("Please select a recipe to display.");
            }
        }

        private void ApplyFilter_Click(object sender, RoutedEventArgs e)
        {
            string ingredientName = FilterIngredientNameTextBox.Text;
            string foodGroup = FilterFoodGroupTextBox.Text;
            bool hasMaxCalories = int.TryParse(FilterCaloriesTextBox.Text, out int maxCalories);

            var filteredRecipes = recipes.Where(r =>
            {
                bool matchesIngredient = string.IsNullOrEmpty(ingredientName) || r.ContainsIngredient(ingredientName);
                bool matchesFoodGroup = string.IsNullOrEmpty(foodGroup) || r.BelongsToFoodGroup(foodGroup);
                bool matchesCalories = !hasMaxCalories || r.CalculateTotalCalories() <= maxCalories;

                return matchesIngredient && matchesFoodGroup && matchesCalories;
            });

            RecipeListBox.ItemsSource = filteredRecipes.OrderBy(r => r.Name).Select(r => r.Name).ToList();
        }

        private void ClearIngredientFields()
        {
            IngredientNameTextBox.Clear();
            QuantityTextBox.Clear();
            UnitTextBox.Clear();
            CaloriesTextBox.Clear();
            FoodGroupTextBox.Clear();
        }

        private void ClearAllFields()
        {
            RecipeNameTextBox.Clear();
            StepDescriptionTextBox.Clear();
            ClearIngredientFields();
        }
    }
}

