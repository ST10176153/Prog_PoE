//Recipe.cs
using System;
using System.Collections.Generic;

public class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients { get; set; }
    public List<string> Steps { get; set; }

    public Recipe(string name)
    {
        Name = name;
        Ingredients = new List<Ingredient>();
        Steps = new List<string>();
    }

    public void AddIngredient(Ingredient ingredient)
    {
        Ingredients.Add(ingredient);
    }

    public void AddStep(string step)
    {
        Steps.Add(step);
    }

    public int CalculateTotalCalories()
    {
        int totalCalories = 0;
        foreach (var ingredient in Ingredients)
        {
            totalCalories += ingredient.Calories;
        }
        return totalCalories;
    }

    public bool ContainsIngredient(string ingredientName)
    {
        foreach (var ingredient in Ingredients)
        {
            if (ingredient.Name.Contains(ingredientName, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }
        return false;
    }

    public bool BelongsToFoodGroup(string foodGroup)
    {
            foreach (var ingredient in Ingredients)
            {
                if (ingredient.FoodGroup.Equals(foodGroup, StringComparison.OrdinalIgnoreCase)) 
            { 
                    return true;
            }
        }
        return false;
    }
}
